# Stock-Market-Prediction
Create a hybrid model for stock price or performance prediction using numerical analysis of historical stock prices, and sentimental analysis of news headlines. The stock to analyze and predict is SENSEX (S&P BSE SENSEX)

Conclusion

RandomForest = 0.05257968397499098
DecisionTree = 0.10831900809236311AdaBoost = 0.05492347045438241
LightGBM = 0.0583079056070462
XGBoost = 0.05968830860645931 From here we can see that RandomForestRegressor shows a better performance than the others
